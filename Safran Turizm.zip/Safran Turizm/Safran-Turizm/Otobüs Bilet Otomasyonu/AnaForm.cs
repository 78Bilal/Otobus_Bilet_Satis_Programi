﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Otobüs_Bilet_Otomasyonu
{
    public partial class AnaForm : Form
    {
        public AnaForm()
        {
            InitializeComponent();
        }

        private void markaİşmeleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MarkaIslemleri markaislemleri = new MarkaIslemleri();
            markaislemleri.Show();
            this.Close();
        }

        private void otobüsDetayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OtobusDetay otobusdetay = new OtobusDetay();
            otobusdetay.Show();
            this.Close();
        }

        private void şubeİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SubeIslemleri subeislemleri = new SubeIslemleri();
            subeislemleri.Show();
            this.Close();
        }

        private void personelİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Personel personel = new Personel();
            personel.Show();
            this.Close();
        }

        private void masrafİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasrafCesitleri masraf = new MasrafCesitleri();
            masraf.Show();
            this.Close();
        }

        private void pozisyonİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PozisyonIslemleri pozisyon = new PozisyonIslemleri();
            pozisyon.Show();
            this.Close();
        }

        private void guzergahİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            GuzergahIslemleri guzergah = new GuzergahIslemleri();
            guzergah.Show();
            this.Close();
        }

        private void seferİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Seferim sefer = new Seferim();
            sefer.Show();
            this.Close();
        }

        private void AnaForm_Load(object sender, EventArgs e)
        {
        }

        private void biletİşlemleriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bilet bilet = new bilet();
            bilet.Show();
            this.Close();
        }

        private void yönetimselAraçlarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void biletİşlemleriToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            bilet bilet = new bilet();
            bilet.Show();
            this.Close();
        }

       
    }
}

﻿namespace Otobüs_Bilet_Otomasyonu
{
    partial class bilet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.cmbIslemTipi = new System.Windows.Forms.ComboBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtUcret = new System.Windows.Forms.TextBox();
            this.txtYolcuAdSoyad = new System.Windows.Forms.TextBox();
            this.cmbCinsiyet = new System.Windows.Forms.ComboBox();
            this.cmbKoltukNo = new System.Windows.Forms.ComboBox();
            this.cmbSeferSec = new System.Windows.Forms.ComboBox();
            this.cmbGuzergahSec = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnKoltuk46 = new System.Windows.Forms.Button();
            this.btnKoltuk45 = new System.Windows.Forms.Button();
            this.btnKoltuk44 = new System.Windows.Forms.Button();
            this.btnKoltuk43 = new System.Windows.Forms.Button();
            this.btnKoltuk42 = new System.Windows.Forms.Button();
            this.btnKoltuk41 = new System.Windows.Forms.Button();
            this.btnKoltuk40 = new System.Windows.Forms.Button();
            this.btnKoltuk39 = new System.Windows.Forms.Button();
            this.btnKoltuk38 = new System.Windows.Forms.Button();
            this.btnKoltuk37 = new System.Windows.Forms.Button();
            this.btnKoltuk36 = new System.Windows.Forms.Button();
            this.btnKoltuk35 = new System.Windows.Forms.Button();
            this.btnKoltuk34 = new System.Windows.Forms.Button();
            this.btnKoltuk33 = new System.Windows.Forms.Button();
            this.btnKoltuk32 = new System.Windows.Forms.Button();
            this.btnKoltuk31 = new System.Windows.Forms.Button();
            this.btnKoltuk30 = new System.Windows.Forms.Button();
            this.btnKoltuk29 = new System.Windows.Forms.Button();
            this.btnKoltuk28 = new System.Windows.Forms.Button();
            this.btnKoltuk27 = new System.Windows.Forms.Button();
            this.btnKoltuk26 = new System.Windows.Forms.Button();
            this.btnKoltuk25 = new System.Windows.Forms.Button();
            this.btnKoltuk24 = new System.Windows.Forms.Button();
            this.btnKoltuk23 = new System.Windows.Forms.Button();
            this.btnKoltuk22 = new System.Windows.Forms.Button();
            this.btnKoltuk21 = new System.Windows.Forms.Button();
            this.btnKoltuk20 = new System.Windows.Forms.Button();
            this.btnKoltuk19 = new System.Windows.Forms.Button();
            this.btnKoltuk18 = new System.Windows.Forms.Button();
            this.btnKoltuk17 = new System.Windows.Forms.Button();
            this.btnKoltuk16 = new System.Windows.Forms.Button();
            this.btnKoltuk15 = new System.Windows.Forms.Button();
            this.btnKoltuk14 = new System.Windows.Forms.Button();
            this.btnKoltuk13 = new System.Windows.Forms.Button();
            this.btnKoltuk12 = new System.Windows.Forms.Button();
            this.btnKoltuk11 = new System.Windows.Forms.Button();
            this.btnKoltuk10 = new System.Windows.Forms.Button();
            this.btnKoltuk9 = new System.Windows.Forms.Button();
            this.btnKoltuk8 = new System.Windows.Forms.Button();
            this.btnKoltuk7 = new System.Windows.Forms.Button();
            this.btnKoltuk6 = new System.Windows.Forms.Button();
            this.btnKoltuk5 = new System.Windows.Forms.Button();
            this.btnKoltuk4 = new System.Windows.Forms.Button();
            this.btnKoltuk3 = new System.Windows.Forms.Button();
            this.btnKoltuk2 = new System.Windows.Forms.Button();
            this.btnKoltuk1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.cmbIslemTipi);
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.button2);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.txtUcret);
            this.groupBox1.Controls.Add(this.txtYolcuAdSoyad);
            this.groupBox1.Controls.Add(this.cmbCinsiyet);
            this.groupBox1.Controls.Add(this.cmbKoltukNo);
            this.groupBox1.Controls.Add(this.cmbSeferSec);
            this.groupBox1.Controls.Add(this.cmbGuzergahSec);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnKoltuk46);
            this.groupBox1.Controls.Add(this.btnKoltuk45);
            this.groupBox1.Controls.Add(this.btnKoltuk44);
            this.groupBox1.Controls.Add(this.btnKoltuk43);
            this.groupBox1.Controls.Add(this.btnKoltuk42);
            this.groupBox1.Controls.Add(this.btnKoltuk41);
            this.groupBox1.Controls.Add(this.btnKoltuk40);
            this.groupBox1.Controls.Add(this.btnKoltuk39);
            this.groupBox1.Controls.Add(this.btnKoltuk38);
            this.groupBox1.Controls.Add(this.btnKoltuk37);
            this.groupBox1.Controls.Add(this.btnKoltuk36);
            this.groupBox1.Controls.Add(this.btnKoltuk35);
            this.groupBox1.Controls.Add(this.btnKoltuk34);
            this.groupBox1.Controls.Add(this.btnKoltuk33);
            this.groupBox1.Controls.Add(this.btnKoltuk32);
            this.groupBox1.Controls.Add(this.btnKoltuk31);
            this.groupBox1.Controls.Add(this.btnKoltuk30);
            this.groupBox1.Controls.Add(this.btnKoltuk29);
            this.groupBox1.Controls.Add(this.btnKoltuk28);
            this.groupBox1.Controls.Add(this.btnKoltuk27);
            this.groupBox1.Controls.Add(this.btnKoltuk26);
            this.groupBox1.Controls.Add(this.btnKoltuk25);
            this.groupBox1.Controls.Add(this.btnKoltuk24);
            this.groupBox1.Controls.Add(this.btnKoltuk23);
            this.groupBox1.Controls.Add(this.btnKoltuk22);
            this.groupBox1.Controls.Add(this.btnKoltuk21);
            this.groupBox1.Controls.Add(this.btnKoltuk20);
            this.groupBox1.Controls.Add(this.btnKoltuk19);
            this.groupBox1.Controls.Add(this.btnKoltuk18);
            this.groupBox1.Controls.Add(this.btnKoltuk17);
            this.groupBox1.Controls.Add(this.btnKoltuk16);
            this.groupBox1.Controls.Add(this.btnKoltuk15);
            this.groupBox1.Controls.Add(this.btnKoltuk14);
            this.groupBox1.Controls.Add(this.btnKoltuk13);
            this.groupBox1.Controls.Add(this.btnKoltuk12);
            this.groupBox1.Controls.Add(this.btnKoltuk11);
            this.groupBox1.Controls.Add(this.btnKoltuk10);
            this.groupBox1.Controls.Add(this.btnKoltuk9);
            this.groupBox1.Controls.Add(this.btnKoltuk8);
            this.groupBox1.Controls.Add(this.btnKoltuk7);
            this.groupBox1.Controls.Add(this.btnKoltuk6);
            this.groupBox1.Controls.Add(this.btnKoltuk5);
            this.groupBox1.Controls.Add(this.btnKoltuk4);
            this.groupBox1.Controls.Add(this.btnKoltuk3);
            this.groupBox1.Controls.Add(this.btnKoltuk2);
            this.groupBox1.Controls.Add(this.btnKoltuk1);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.Location = new System.Drawing.Point(16, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(767, 582);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bilet İşlemleri";
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button5.Location = new System.Drawing.Point(12, 491);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(73, 74);
            this.button5.TabIndex = 70;
            this.button5.Text = "🏠";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // cmbIslemTipi
            // 
            this.cmbIslemTipi.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbIslemTipi.FormattingEnabled = true;
            this.cmbIslemTipi.Location = new System.Drawing.Point(209, 135);
            this.cmbIslemTipi.Margin = new System.Windows.Forms.Padding(4);
            this.cmbIslemTipi.Name = "cmbIslemTipi";
            this.cmbIslemTipi.Size = new System.Drawing.Size(226, 32);
            this.cmbIslemTipi.TabIndex = 69;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Green;
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(375, 478);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(51, 30);
            this.button4.TabIndex = 68;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Blue;
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(375, 440);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(51, 23);
            this.button3.TabIndex = 67;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Pink;
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(374, 395);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(52, 23);
            this.button2.TabIndex = 66;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Enabled = false;
            this.label10.Location = new System.Drawing.Point(307, 484);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 24);
            this.label10.TabIndex = 65;
            this.label10.Text = "Boş:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Enabled = false;
            this.label9.Location = new System.Drawing.Point(306, 440);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 24);
            this.label9.TabIndex = 64;
            this.label9.Text = "Bay:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Enabled = false;
            this.label8.Location = new System.Drawing.Point(279, 395);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 24);
            this.label8.TabIndex = 63;
            this.label8.Text = "Bayan:";
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.button1.Location = new System.Drawing.Point(102, 388);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 37);
            this.button1.TabIndex = 61;
            this.button1.Text = "Bileti Sat";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtUcret
            // 
            this.txtUcret.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtUcret.Location = new System.Drawing.Point(209, 326);
            this.txtUcret.Margin = new System.Windows.Forms.Padding(4);
            this.txtUcret.Name = "txtUcret";
            this.txtUcret.Size = new System.Drawing.Size(226, 32);
            this.txtUcret.TabIndex = 60;
            // 
            // txtYolcuAdSoyad
            // 
            this.txtYolcuAdSoyad.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtYolcuAdSoyad.Location = new System.Drawing.Point(209, 282);
            this.txtYolcuAdSoyad.Margin = new System.Windows.Forms.Padding(4);
            this.txtYolcuAdSoyad.Name = "txtYolcuAdSoyad";
            this.txtYolcuAdSoyad.Size = new System.Drawing.Size(226, 32);
            this.txtYolcuAdSoyad.TabIndex = 59;
            // 
            // cmbCinsiyet
            // 
            this.cmbCinsiyet.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCinsiyet.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cmbCinsiyet.FormattingEnabled = true;
            this.cmbCinsiyet.Location = new System.Drawing.Point(209, 238);
            this.cmbCinsiyet.Margin = new System.Windows.Forms.Padding(4);
            this.cmbCinsiyet.Name = "cmbCinsiyet";
            this.cmbCinsiyet.Size = new System.Drawing.Size(226, 32);
            this.cmbCinsiyet.TabIndex = 58;
            // 
            // cmbKoltukNo
            // 
            this.cmbKoltukNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbKoltukNo.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cmbKoltukNo.FormattingEnabled = true;
            this.cmbKoltukNo.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46"});
            this.cmbKoltukNo.Location = new System.Drawing.Point(209, 182);
            this.cmbKoltukNo.Margin = new System.Windows.Forms.Padding(4);
            this.cmbKoltukNo.Name = "cmbKoltukNo";
            this.cmbKoltukNo.Size = new System.Drawing.Size(226, 32);
            this.cmbKoltukNo.TabIndex = 57;
            // 
            // cmbSeferSec
            // 
            this.cmbSeferSec.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSeferSec.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cmbSeferSec.FormattingEnabled = true;
            this.cmbSeferSec.Location = new System.Drawing.Point(209, 91);
            this.cmbSeferSec.Margin = new System.Windows.Forms.Padding(4);
            this.cmbSeferSec.Name = "cmbSeferSec";
            this.cmbSeferSec.Size = new System.Drawing.Size(226, 32);
            this.cmbSeferSec.TabIndex = 54;
            this.cmbSeferSec.SelectedValueChanged += new System.EventHandler(this.cmbSeferSec_SelectedValueChanged);
            // 
            // cmbGuzergahSec
            // 
            this.cmbGuzergahSec.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGuzergahSec.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.cmbGuzergahSec.FormattingEnabled = true;
            this.cmbGuzergahSec.Location = new System.Drawing.Point(209, 44);
            this.cmbGuzergahSec.Margin = new System.Windows.Forms.Padding(4);
            this.cmbGuzergahSec.Name = "cmbGuzergahSec";
            this.cmbGuzergahSec.Size = new System.Drawing.Size(226, 32);
            this.cmbGuzergahSec.TabIndex = 53;
            this.cmbGuzergahSec.SelectedValueChanged += new System.EventHandler(this.cmbGuzergahSec_SelectedValueChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(98, 334);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 24);
            this.label7.TabIndex = 52;
            this.label7.Text = "Ücret:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(25, 290);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(173, 24);
            this.label6.TabIndex = 51;
            this.label6.Text = "Yolcu Ad Soyad:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(81, 245);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 24);
            this.label5.TabIndex = 50;
            this.label5.Text = "Cinsiyet:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(66, 190);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(115, 24);
            this.label4.TabIndex = 49;
            this.label4.Text = "Koltuk No:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(66, 143);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 24);
            this.label3.TabIndex = 48;
            this.label3.Text = "İşlem Tipi:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(41, 99);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 24);
            this.label2.TabIndex = 47;
            this.label2.Text = "Sefer Seçiniz:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(8, 52);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 24);
            this.label1.TabIndex = 46;
            this.label1.Text = "Güzergah Seçiniz:";
            // 
            // btnKoltuk46
            // 
            this.btnKoltuk46.Enabled = false;
            this.btnKoltuk46.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk46.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk46.Location = new System.Drawing.Point(685, 527);
            this.btnKoltuk46.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk46.Name = "btnKoltuk46";
            this.btnKoltuk46.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk46.TabIndex = 45;
            this.btnKoltuk46.Text = "46";
            this.btnKoltuk46.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk45
            // 
            this.btnKoltuk45.Enabled = false;
            this.btnKoltuk45.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk45.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk45.Location = new System.Drawing.Point(621, 527);
            this.btnKoltuk45.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk45.Name = "btnKoltuk45";
            this.btnKoltuk45.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk45.TabIndex = 44;
            this.btnKoltuk45.Text = "45";
            this.btnKoltuk45.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk44
            // 
            this.btnKoltuk44.Enabled = false;
            this.btnKoltuk44.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk44.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk44.Location = new System.Drawing.Point(543, 527);
            this.btnKoltuk44.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk44.Name = "btnKoltuk44";
            this.btnKoltuk44.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk44.TabIndex = 43;
            this.btnKoltuk44.Text = "44";
            this.btnKoltuk44.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk43
            // 
            this.btnKoltuk43.Enabled = false;
            this.btnKoltuk43.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk43.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk43.Location = new System.Drawing.Point(479, 527);
            this.btnKoltuk43.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk43.Name = "btnKoltuk43";
            this.btnKoltuk43.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk43.TabIndex = 42;
            this.btnKoltuk43.Text = "43";
            this.btnKoltuk43.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk42
            // 
            this.btnKoltuk42.Enabled = false;
            this.btnKoltuk42.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk42.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk42.Location = new System.Drawing.Point(685, 483);
            this.btnKoltuk42.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk42.Name = "btnKoltuk42";
            this.btnKoltuk42.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk42.TabIndex = 41;
            this.btnKoltuk42.Text = "42";
            this.btnKoltuk42.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk41
            // 
            this.btnKoltuk41.Enabled = false;
            this.btnKoltuk41.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk41.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk41.Location = new System.Drawing.Point(621, 483);
            this.btnKoltuk41.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk41.Name = "btnKoltuk41";
            this.btnKoltuk41.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk41.TabIndex = 40;
            this.btnKoltuk41.Text = "41";
            this.btnKoltuk41.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk40
            // 
            this.btnKoltuk40.Enabled = false;
            this.btnKoltuk40.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk40.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk40.Location = new System.Drawing.Point(543, 483);
            this.btnKoltuk40.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk40.Name = "btnKoltuk40";
            this.btnKoltuk40.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk40.TabIndex = 39;
            this.btnKoltuk40.Text = "40";
            this.btnKoltuk40.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk39
            // 
            this.btnKoltuk39.Enabled = false;
            this.btnKoltuk39.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk39.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk39.Location = new System.Drawing.Point(479, 483);
            this.btnKoltuk39.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk39.Name = "btnKoltuk39";
            this.btnKoltuk39.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk39.TabIndex = 38;
            this.btnKoltuk39.Text = "39";
            this.btnKoltuk39.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk38
            // 
            this.btnKoltuk38.Enabled = false;
            this.btnKoltuk38.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk38.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk38.Location = new System.Drawing.Point(685, 438);
            this.btnKoltuk38.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk38.Name = "btnKoltuk38";
            this.btnKoltuk38.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk38.TabIndex = 37;
            this.btnKoltuk38.Text = "38";
            this.btnKoltuk38.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk37
            // 
            this.btnKoltuk37.Enabled = false;
            this.btnKoltuk37.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk37.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk37.Location = new System.Drawing.Point(621, 438);
            this.btnKoltuk37.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk37.Name = "btnKoltuk37";
            this.btnKoltuk37.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk37.TabIndex = 36;
            this.btnKoltuk37.Text = "37";
            this.btnKoltuk37.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk36
            // 
            this.btnKoltuk36.Enabled = false;
            this.btnKoltuk36.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk36.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk36.Location = new System.Drawing.Point(543, 438);
            this.btnKoltuk36.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk36.Name = "btnKoltuk36";
            this.btnKoltuk36.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk36.TabIndex = 35;
            this.btnKoltuk36.Text = "36";
            this.btnKoltuk36.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk35
            // 
            this.btnKoltuk35.Enabled = false;
            this.btnKoltuk35.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk35.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk35.Location = new System.Drawing.Point(479, 438);
            this.btnKoltuk35.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk35.Name = "btnKoltuk35";
            this.btnKoltuk35.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk35.TabIndex = 34;
            this.btnKoltuk35.Text = "35";
            this.btnKoltuk35.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk34
            // 
            this.btnKoltuk34.Enabled = false;
            this.btnKoltuk34.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk34.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk34.Location = new System.Drawing.Point(685, 394);
            this.btnKoltuk34.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk34.Name = "btnKoltuk34";
            this.btnKoltuk34.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk34.TabIndex = 33;
            this.btnKoltuk34.Text = "34";
            this.btnKoltuk34.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk33
            // 
            this.btnKoltuk33.Enabled = false;
            this.btnKoltuk33.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk33.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk33.Location = new System.Drawing.Point(621, 394);
            this.btnKoltuk33.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk33.Name = "btnKoltuk33";
            this.btnKoltuk33.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk33.TabIndex = 32;
            this.btnKoltuk33.Text = "33";
            this.btnKoltuk33.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk32
            // 
            this.btnKoltuk32.Enabled = false;
            this.btnKoltuk32.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk32.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk32.Location = new System.Drawing.Point(543, 394);
            this.btnKoltuk32.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk32.Name = "btnKoltuk32";
            this.btnKoltuk32.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk32.TabIndex = 31;
            this.btnKoltuk32.Text = "32";
            this.btnKoltuk32.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk31
            // 
            this.btnKoltuk31.Enabled = false;
            this.btnKoltuk31.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk31.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk31.Location = new System.Drawing.Point(479, 394);
            this.btnKoltuk31.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk31.Name = "btnKoltuk31";
            this.btnKoltuk31.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk31.TabIndex = 30;
            this.btnKoltuk31.Text = "31";
            this.btnKoltuk31.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk30
            // 
            this.btnKoltuk30.Enabled = false;
            this.btnKoltuk30.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk30.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk30.Location = new System.Drawing.Point(685, 350);
            this.btnKoltuk30.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk30.Name = "btnKoltuk30";
            this.btnKoltuk30.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk30.TabIndex = 29;
            this.btnKoltuk30.Text = "30";
            this.btnKoltuk30.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk29
            // 
            this.btnKoltuk29.Enabled = false;
            this.btnKoltuk29.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk29.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk29.Location = new System.Drawing.Point(621, 350);
            this.btnKoltuk29.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk29.Name = "btnKoltuk29";
            this.btnKoltuk29.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk29.TabIndex = 28;
            this.btnKoltuk29.Text = "29";
            this.btnKoltuk29.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk28
            // 
            this.btnKoltuk28.Enabled = false;
            this.btnKoltuk28.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk28.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk28.Location = new System.Drawing.Point(543, 350);
            this.btnKoltuk28.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk28.Name = "btnKoltuk28";
            this.btnKoltuk28.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk28.TabIndex = 27;
            this.btnKoltuk28.Text = "28";
            this.btnKoltuk28.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk27
            // 
            this.btnKoltuk27.Enabled = false;
            this.btnKoltuk27.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk27.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk27.Location = new System.Drawing.Point(479, 350);
            this.btnKoltuk27.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk27.Name = "btnKoltuk27";
            this.btnKoltuk27.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk27.TabIndex = 26;
            this.btnKoltuk27.Text = "27";
            this.btnKoltuk27.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk26
            // 
            this.btnKoltuk26.Enabled = false;
            this.btnKoltuk26.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk26.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk26.Location = new System.Drawing.Point(543, 305);
            this.btnKoltuk26.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk26.Name = "btnKoltuk26";
            this.btnKoltuk26.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk26.TabIndex = 25;
            this.btnKoltuk26.Text = "26";
            this.btnKoltuk26.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk25
            // 
            this.btnKoltuk25.Enabled = false;
            this.btnKoltuk25.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk25.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk25.Location = new System.Drawing.Point(479, 305);
            this.btnKoltuk25.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk25.Name = "btnKoltuk25";
            this.btnKoltuk25.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk25.TabIndex = 24;
            this.btnKoltuk25.Text = "25";
            this.btnKoltuk25.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk24
            // 
            this.btnKoltuk24.Enabled = false;
            this.btnKoltuk24.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk24.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk24.Location = new System.Drawing.Point(685, 261);
            this.btnKoltuk24.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk24.Name = "btnKoltuk24";
            this.btnKoltuk24.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk24.TabIndex = 23;
            this.btnKoltuk24.Text = "24";
            this.btnKoltuk24.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk23
            // 
            this.btnKoltuk23.Enabled = false;
            this.btnKoltuk23.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk23.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk23.Location = new System.Drawing.Point(621, 261);
            this.btnKoltuk23.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk23.Name = "btnKoltuk23";
            this.btnKoltuk23.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk23.TabIndex = 22;
            this.btnKoltuk23.Text = "23";
            this.btnKoltuk23.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk22
            // 
            this.btnKoltuk22.Enabled = false;
            this.btnKoltuk22.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk22.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk22.Location = new System.Drawing.Point(543, 261);
            this.btnKoltuk22.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk22.Name = "btnKoltuk22";
            this.btnKoltuk22.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk22.TabIndex = 21;
            this.btnKoltuk22.Text = "22";
            this.btnKoltuk22.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk21
            // 
            this.btnKoltuk21.Enabled = false;
            this.btnKoltuk21.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk21.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk21.Location = new System.Drawing.Point(479, 261);
            this.btnKoltuk21.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk21.Name = "btnKoltuk21";
            this.btnKoltuk21.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk21.TabIndex = 20;
            this.btnKoltuk21.Text = "21";
            this.btnKoltuk21.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk20
            // 
            this.btnKoltuk20.Enabled = false;
            this.btnKoltuk20.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk20.Location = new System.Drawing.Point(687, 217);
            this.btnKoltuk20.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk20.Name = "btnKoltuk20";
            this.btnKoltuk20.Size = new System.Drawing.Size(53, 37);
            this.btnKoltuk20.TabIndex = 19;
            this.btnKoltuk20.Text = "20";
            this.btnKoltuk20.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk19
            // 
            this.btnKoltuk19.Enabled = false;
            this.btnKoltuk19.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk19.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk19.Location = new System.Drawing.Point(621, 217);
            this.btnKoltuk19.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk19.Name = "btnKoltuk19";
            this.btnKoltuk19.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk19.TabIndex = 18;
            this.btnKoltuk19.Text = "19";
            this.btnKoltuk19.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk18
            // 
            this.btnKoltuk18.Enabled = false;
            this.btnKoltuk18.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk18.Location = new System.Drawing.Point(543, 217);
            this.btnKoltuk18.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk18.Name = "btnKoltuk18";
            this.btnKoltuk18.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk18.TabIndex = 17;
            this.btnKoltuk18.Text = "18";
            this.btnKoltuk18.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk17
            // 
            this.btnKoltuk17.Enabled = false;
            this.btnKoltuk17.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk17.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk17.Location = new System.Drawing.Point(479, 217);
            this.btnKoltuk17.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk17.Name = "btnKoltuk17";
            this.btnKoltuk17.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk17.TabIndex = 16;
            this.btnKoltuk17.Text = "17";
            this.btnKoltuk17.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk16
            // 
            this.btnKoltuk16.Enabled = false;
            this.btnKoltuk16.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk16.Location = new System.Drawing.Point(687, 173);
            this.btnKoltuk16.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk16.Name = "btnKoltuk16";
            this.btnKoltuk16.Size = new System.Drawing.Size(53, 37);
            this.btnKoltuk16.TabIndex = 15;
            this.btnKoltuk16.Text = "16";
            this.btnKoltuk16.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk15
            // 
            this.btnKoltuk15.Enabled = false;
            this.btnKoltuk15.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk15.Location = new System.Drawing.Point(621, 173);
            this.btnKoltuk15.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk15.Name = "btnKoltuk15";
            this.btnKoltuk15.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk15.TabIndex = 14;
            this.btnKoltuk15.Text = "15";
            this.btnKoltuk15.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk14
            // 
            this.btnKoltuk14.Enabled = false;
            this.btnKoltuk14.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk14.Location = new System.Drawing.Point(543, 173);
            this.btnKoltuk14.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk14.Name = "btnKoltuk14";
            this.btnKoltuk14.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk14.TabIndex = 13;
            this.btnKoltuk14.Text = "14";
            this.btnKoltuk14.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk13
            // 
            this.btnKoltuk13.Enabled = false;
            this.btnKoltuk13.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk13.Location = new System.Drawing.Point(479, 173);
            this.btnKoltuk13.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk13.Name = "btnKoltuk13";
            this.btnKoltuk13.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk13.TabIndex = 12;
            this.btnKoltuk13.Text = "13";
            this.btnKoltuk13.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk12
            // 
            this.btnKoltuk12.Enabled = false;
            this.btnKoltuk12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk12.Location = new System.Drawing.Point(685, 128);
            this.btnKoltuk12.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk12.Name = "btnKoltuk12";
            this.btnKoltuk12.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk12.TabIndex = 11;
            this.btnKoltuk12.Text = "12";
            this.btnKoltuk12.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk11
            // 
            this.btnKoltuk11.Enabled = false;
            this.btnKoltuk11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk11.Location = new System.Drawing.Point(621, 128);
            this.btnKoltuk11.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk11.Name = "btnKoltuk11";
            this.btnKoltuk11.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk11.TabIndex = 10;
            this.btnKoltuk11.Text = "11";
            this.btnKoltuk11.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk10
            // 
            this.btnKoltuk10.Enabled = false;
            this.btnKoltuk10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk10.Location = new System.Drawing.Point(543, 128);
            this.btnKoltuk10.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk10.Name = "btnKoltuk10";
            this.btnKoltuk10.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk10.TabIndex = 9;
            this.btnKoltuk10.Text = "10";
            this.btnKoltuk10.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk9
            // 
            this.btnKoltuk9.Enabled = false;
            this.btnKoltuk9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk9.Location = new System.Drawing.Point(479, 128);
            this.btnKoltuk9.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk9.Name = "btnKoltuk9";
            this.btnKoltuk9.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk9.TabIndex = 8;
            this.btnKoltuk9.Text = "9";
            this.btnKoltuk9.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk8
            // 
            this.btnKoltuk8.Enabled = false;
            this.btnKoltuk8.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk8.Location = new System.Drawing.Point(687, 84);
            this.btnKoltuk8.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk8.Name = "btnKoltuk8";
            this.btnKoltuk8.Size = new System.Drawing.Size(53, 37);
            this.btnKoltuk8.TabIndex = 7;
            this.btnKoltuk8.Text = "8";
            this.btnKoltuk8.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk7
            // 
            this.btnKoltuk7.Enabled = false;
            this.btnKoltuk7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk7.Location = new System.Drawing.Point(621, 84);
            this.btnKoltuk7.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk7.Name = "btnKoltuk7";
            this.btnKoltuk7.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk7.TabIndex = 6;
            this.btnKoltuk7.Text = "7";
            this.btnKoltuk7.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk6
            // 
            this.btnKoltuk6.Enabled = false;
            this.btnKoltuk6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk6.Location = new System.Drawing.Point(543, 84);
            this.btnKoltuk6.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk6.Name = "btnKoltuk6";
            this.btnKoltuk6.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk6.TabIndex = 5;
            this.btnKoltuk6.Text = "6";
            this.btnKoltuk6.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk5
            // 
            this.btnKoltuk5.Enabled = false;
            this.btnKoltuk5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk5.Location = new System.Drawing.Point(479, 84);
            this.btnKoltuk5.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk5.Name = "btnKoltuk5";
            this.btnKoltuk5.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk5.TabIndex = 4;
            this.btnKoltuk5.Text = "5";
            this.btnKoltuk5.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk4
            // 
            this.btnKoltuk4.Enabled = false;
            this.btnKoltuk4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk4.Location = new System.Drawing.Point(685, 38);
            this.btnKoltuk4.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk4.Name = "btnKoltuk4";
            this.btnKoltuk4.Size = new System.Drawing.Size(56, 38);
            this.btnKoltuk4.TabIndex = 3;
            this.btnKoltuk4.Text = "4";
            this.btnKoltuk4.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk3
            // 
            this.btnKoltuk3.Enabled = false;
            this.btnKoltuk3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk3.Location = new System.Drawing.Point(621, 38);
            this.btnKoltuk3.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk3.Name = "btnKoltuk3";
            this.btnKoltuk3.Size = new System.Drawing.Size(56, 38);
            this.btnKoltuk3.TabIndex = 2;
            this.btnKoltuk3.Text = "3";
            this.btnKoltuk3.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk2
            // 
            this.btnKoltuk2.Enabled = false;
            this.btnKoltuk2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk2.Location = new System.Drawing.Point(543, 40);
            this.btnKoltuk2.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk2.Name = "btnKoltuk2";
            this.btnKoltuk2.Size = new System.Drawing.Size(56, 37);
            this.btnKoltuk2.TabIndex = 1;
            this.btnKoltuk2.Text = "2";
            this.btnKoltuk2.UseVisualStyleBackColor = true;
            // 
            // btnKoltuk1
            // 
            this.btnKoltuk1.Enabled = false;
            this.btnKoltuk1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnKoltuk1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnKoltuk1.Location = new System.Drawing.Point(479, 38);
            this.btnKoltuk1.Margin = new System.Windows.Forms.Padding(4);
            this.btnKoltuk1.Name = "btnKoltuk1";
            this.btnKoltuk1.Size = new System.Drawing.Size(56, 38);
            this.btnKoltuk1.TabIndex = 0;
            this.btnKoltuk1.Text = "1";
            this.btnKoltuk1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(791, 26);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(492, 553);
            this.dataGridView1.TabIndex = 4;
            // 
            // bilet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1316, 623);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "bilet";
            this.Text = "Bilet İşlemleri";
            this.Load += new System.EventHandler(this.bilet_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtUcret;
        private System.Windows.Forms.TextBox txtYolcuAdSoyad;
        private System.Windows.Forms.ComboBox cmbCinsiyet;
        private System.Windows.Forms.ComboBox cmbKoltukNo;
        private System.Windows.Forms.ComboBox cmbSeferSec;
        private System.Windows.Forms.ComboBox cmbGuzergahSec;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnKoltuk46;
        private System.Windows.Forms.Button btnKoltuk45;
        private System.Windows.Forms.Button btnKoltuk44;
        private System.Windows.Forms.Button btnKoltuk43;
        private System.Windows.Forms.Button btnKoltuk42;
        private System.Windows.Forms.Button btnKoltuk41;
        private System.Windows.Forms.Button btnKoltuk40;
        private System.Windows.Forms.Button btnKoltuk39;
        private System.Windows.Forms.Button btnKoltuk38;
        private System.Windows.Forms.Button btnKoltuk37;
        private System.Windows.Forms.Button btnKoltuk36;
        private System.Windows.Forms.Button btnKoltuk35;
        private System.Windows.Forms.Button btnKoltuk34;
        private System.Windows.Forms.Button btnKoltuk33;
        private System.Windows.Forms.Button btnKoltuk32;
        private System.Windows.Forms.Button btnKoltuk31;
        private System.Windows.Forms.Button btnKoltuk30;
        private System.Windows.Forms.Button btnKoltuk29;
        private System.Windows.Forms.Button btnKoltuk28;
        private System.Windows.Forms.Button btnKoltuk27;
        private System.Windows.Forms.Button btnKoltuk26;
        private System.Windows.Forms.Button btnKoltuk25;
        private System.Windows.Forms.Button btnKoltuk24;
        private System.Windows.Forms.Button btnKoltuk23;
        private System.Windows.Forms.Button btnKoltuk22;
        private System.Windows.Forms.Button btnKoltuk21;
        private System.Windows.Forms.Button btnKoltuk20;
        private System.Windows.Forms.Button btnKoltuk19;
        private System.Windows.Forms.Button btnKoltuk18;
        private System.Windows.Forms.Button btnKoltuk17;
        private System.Windows.Forms.Button btnKoltuk16;
        private System.Windows.Forms.Button btnKoltuk15;
        private System.Windows.Forms.Button btnKoltuk14;
        private System.Windows.Forms.Button btnKoltuk13;
        private System.Windows.Forms.Button btnKoltuk12;
        private System.Windows.Forms.Button btnKoltuk11;
        private System.Windows.Forms.Button btnKoltuk10;
        private System.Windows.Forms.Button btnKoltuk9;
        private System.Windows.Forms.Button btnKoltuk8;
        private System.Windows.Forms.Button btnKoltuk7;
        private System.Windows.Forms.Button btnKoltuk6;
        private System.Windows.Forms.Button btnKoltuk5;
        private System.Windows.Forms.Button btnKoltuk4;
        private System.Windows.Forms.Button btnKoltuk3;
        private System.Windows.Forms.Button btnKoltuk2;
        private System.Windows.Forms.Button btnKoltuk1;
        private System.Windows.Forms.ComboBox cmbIslemTipi;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button5;
    }
}
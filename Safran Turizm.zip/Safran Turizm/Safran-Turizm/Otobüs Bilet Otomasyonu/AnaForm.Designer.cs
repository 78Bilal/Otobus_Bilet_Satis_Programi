﻿namespace Otobüs_Bilet_Otomasyonu
{
    partial class AnaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.yönetimselAraçlarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.markaİşmeleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otobüsDetayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.şubeİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.personelİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masrafİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pozisyonİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.guzergahİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.seferİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.biletİşlemleriToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.yönetimselAraçlarToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1779, 32);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // yönetimselAraçlarToolStripMenuItem
            // 
            this.yönetimselAraçlarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.markaİşmeleriToolStripMenuItem,
            this.otobüsDetayToolStripMenuItem,
            this.şubeİşlemleriToolStripMenuItem,
            this.personelİşlemleriToolStripMenuItem,
            this.masrafİşlemleriToolStripMenuItem,
            this.pozisyonİşlemleriToolStripMenuItem,
            this.guzergahİşlemleriToolStripMenuItem,
            this.seferİşlemleriToolStripMenuItem,
            this.biletİşlemleriToolStripMenuItem});
            this.yönetimselAraçlarToolStripMenuItem.Name = "yönetimselAraçlarToolStripMenuItem";
            this.yönetimselAraçlarToolStripMenuItem.Size = new System.Drawing.Size(108, 28);
            this.yönetimselAraçlarToolStripMenuItem.Text = "İşlemler";
            this.yönetimselAraçlarToolStripMenuItem.Click += new System.EventHandler(this.yönetimselAraçlarToolStripMenuItem_Click);
            // 
            // markaİşmeleriToolStripMenuItem
            // 
            this.markaİşmeleriToolStripMenuItem.Name = "markaİşmeleriToolStripMenuItem";
            this.markaİşmeleriToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.markaİşmeleriToolStripMenuItem.Text = "Marka İşmeleri";
            this.markaİşmeleriToolStripMenuItem.Click += new System.EventHandler(this.markaİşmeleriToolStripMenuItem_Click);
            // 
            // otobüsDetayToolStripMenuItem
            // 
            this.otobüsDetayToolStripMenuItem.Name = "otobüsDetayToolStripMenuItem";
            this.otobüsDetayToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.otobüsDetayToolStripMenuItem.Text = "Otobüs İşlemleri";
            this.otobüsDetayToolStripMenuItem.Click += new System.EventHandler(this.otobüsDetayToolStripMenuItem_Click);
            // 
            // şubeİşlemleriToolStripMenuItem
            // 
            this.şubeİşlemleriToolStripMenuItem.Name = "şubeİşlemleriToolStripMenuItem";
            this.şubeİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.şubeİşlemleriToolStripMenuItem.Text = "Şube İşlemleri";
            this.şubeİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.şubeİşlemleriToolStripMenuItem_Click);
            // 
            // personelİşlemleriToolStripMenuItem
            // 
            this.personelİşlemleriToolStripMenuItem.Name = "personelİşlemleriToolStripMenuItem";
            this.personelİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.personelİşlemleriToolStripMenuItem.Text = "Personel İşlemleri";
            this.personelİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.personelİşlemleriToolStripMenuItem_Click);
            // 
            // masrafİşlemleriToolStripMenuItem
            // 
            this.masrafİşlemleriToolStripMenuItem.Name = "masrafİşlemleriToolStripMenuItem";
            this.masrafİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.masrafİşlemleriToolStripMenuItem.Text = "Masraf İşlemleri";
            this.masrafİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.masrafİşlemleriToolStripMenuItem_Click);
            // 
            // pozisyonİşlemleriToolStripMenuItem
            // 
            this.pozisyonİşlemleriToolStripMenuItem.Name = "pozisyonİşlemleriToolStripMenuItem";
            this.pozisyonİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.pozisyonİşlemleriToolStripMenuItem.Text = "Pozisyon İşlemleri";
            this.pozisyonİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.pozisyonİşlemleriToolStripMenuItem_Click);
            // 
            // guzergahİşlemleriToolStripMenuItem
            // 
            this.guzergahİşlemleriToolStripMenuItem.Name = "guzergahİşlemleriToolStripMenuItem";
            this.guzergahİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.guzergahİşlemleriToolStripMenuItem.Text = "Guzergah İşlemleri";
            this.guzergahİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.guzergahİşlemleriToolStripMenuItem_Click);
            // 
            // seferİşlemleriToolStripMenuItem
            // 
            this.seferİşlemleriToolStripMenuItem.Name = "seferİşlemleriToolStripMenuItem";
            this.seferİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.seferİşlemleriToolStripMenuItem.Text = "Sefer İşlemleri";
            this.seferİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.seferİşlemleriToolStripMenuItem_Click);
            // 
            // biletİşlemleriToolStripMenuItem
            // 
            this.biletİşlemleriToolStripMenuItem.Name = "biletİşlemleriToolStripMenuItem";
            this.biletİşlemleriToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.biletİşlemleriToolStripMenuItem.Text = "Bilet İşlemleri";
            this.biletİşlemleriToolStripMenuItem.Click += new System.EventHandler(this.biletİşlemleriToolStripMenuItem_Click_1);
            // 
            // AnaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Otobüs_Bilet_Otomasyonu.Properties.Resources.safran_turizm_oge_resim_4;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1779, 838);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "AnaForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds;
            this.Text = "AnaForm";
            this.Load += new System.EventHandler(this.AnaForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem yönetimselAraçlarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem markaİşmeleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otobüsDetayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem şubeİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem personelİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem masrafİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pozisyonİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem guzergahİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seferİşlemleriToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem biletİşlemleriToolStripMenuItem;
    }
}